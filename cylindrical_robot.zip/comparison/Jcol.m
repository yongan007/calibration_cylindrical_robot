function j = Jcol(m)
   j = [m(1:3,4);m(3,2);m(1,3);m(2,1)];
end