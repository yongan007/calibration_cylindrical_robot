function t = Ty(a)
   t = eye(4);
   t(2,4) = a;
end