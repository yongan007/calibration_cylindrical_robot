function t = dTy(a)
   t = zeros(4);
   t(2,4) = 1;
end