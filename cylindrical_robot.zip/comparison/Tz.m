function t = Tz(a)
   t = eye(4);
   t(3,4) = a;
end