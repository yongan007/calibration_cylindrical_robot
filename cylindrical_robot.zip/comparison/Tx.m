function t = Tx(a)
   t = eye(4);
   t(1,4) = a;
end