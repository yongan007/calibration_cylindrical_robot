function t = dTz(a)
   t = zeros(4);
   t(3,4) = 1;
end