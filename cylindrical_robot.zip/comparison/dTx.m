function t = dTx(a)
   t = zeros(4);
   t(1,4) = 1;
end